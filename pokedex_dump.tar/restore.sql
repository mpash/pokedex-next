--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2 (Debian 15.2-1.pgdg110+1)
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pokedex;
--
-- Name: pokedex; Type: DATABASE; Schema: -; Owner: pokedex
--

CREATE DATABASE pokedex WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE pokedex OWNER TO pokedex;

\connect pokedex

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pokedex
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO pokedex;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pokedex
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: JapaneseMeta; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."JapaneseMeta" (
    id integer NOT NULL,
    kyodai_flg integer NOT NULL,
    image_s text NOT NULL,
    sub_name text NOT NULL,
    sub integer NOT NULL,
    type_2 integer NOT NULL,
    image_m text NOT NULL,
    no text NOT NULL,
    type_1 integer NOT NULL,
    takasa text NOT NULL,
    zukan_no text NOT NULL,
    name text NOT NULL,
    omosa text NOT NULL,
    "pokemonId" integer NOT NULL
);


ALTER TABLE public."JapaneseMeta" OWNER TO pokedex;

--
-- Name: JapaneseMeta_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."JapaneseMeta_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."JapaneseMeta_id_seq" OWNER TO pokedex;

--
-- Name: JapaneseMeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."JapaneseMeta_id_seq" OWNED BY public."JapaneseMeta".id;


--
-- Name: Pokemon; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."Pokemon" (
    id integer NOT NULL,
    "sourceId" integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    number text NOT NULL,
    weight double precision NOT NULL,
    height integer NOT NULL,
    hp integer,
    attack integer,
    defense integer,
    "spAttack" integer,
    "spDefense" integer,
    speed integer,
    image text NOT NULL,
    "descriptionX" text NOT NULL,
    "descriptionY" text NOT NULL,
    "detailPageURL" text NOT NULL,
    "collectiblesSlug" text NOT NULL,
    "thumbnailAltText" text NOT NULL,
    "thumbnailImage" text NOT NULL,
    "subVariant" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "regionId" integer
);


ALTER TABLE public."Pokemon" OWNER TO pokedex;

--
-- Name: PokemonAbility; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."PokemonAbility" (
    id integer NOT NULL,
    ability text NOT NULL
);


ALTER TABLE public."PokemonAbility" OWNER TO pokedex;

--
-- Name: PokemonAbility_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."PokemonAbility_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PokemonAbility_id_seq" OWNER TO pokedex;

--
-- Name: PokemonAbility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."PokemonAbility_id_seq" OWNED BY public."PokemonAbility".id;


--
-- Name: PokemonEvolution; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."PokemonEvolution" (
    id integer NOT NULL,
    "order" integer NOT NULL,
    "evolveFromId" integer NOT NULL,
    "evolveToId" integer NOT NULL
);


ALTER TABLE public."PokemonEvolution" OWNER TO pokedex;

--
-- Name: PokemonEvolution_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."PokemonEvolution_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PokemonEvolution_id_seq" OWNER TO pokedex;

--
-- Name: PokemonEvolution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."PokemonEvolution_id_seq" OWNED BY public."PokemonEvolution".id;


--
-- Name: PokemonType; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."PokemonType" (
    id integer NOT NULL,
    type text NOT NULL
);


ALTER TABLE public."PokemonType" OWNER TO pokedex;

--
-- Name: PokemonType_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."PokemonType_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PokemonType_id_seq" OWNER TO pokedex;

--
-- Name: PokemonType_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."PokemonType_id_seq" OWNED BY public."PokemonType".id;


--
-- Name: Pokemon_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."Pokemon_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Pokemon_id_seq" OWNER TO pokedex;

--
-- Name: Pokemon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."Pokemon_id_seq" OWNED BY public."Pokemon".id;


--
-- Name: PrimaryColor; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."PrimaryColor" (
    id integer NOT NULL,
    r integer NOT NULL,
    g integer NOT NULL,
    b integer NOT NULL,
    "pokemonId" integer NOT NULL
);


ALTER TABLE public."PrimaryColor" OWNER TO pokedex;

--
-- Name: PrimaryColor_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."PrimaryColor_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PrimaryColor_id_seq" OWNER TO pokedex;

--
-- Name: PrimaryColor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."PrimaryColor_id_seq" OWNED BY public."PrimaryColor".id;


--
-- Name: Region; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."Region" (
    id integer NOT NULL,
    "sourceId" integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Region" OWNER TO pokedex;

--
-- Name: Region_id_seq; Type: SEQUENCE; Schema: public; Owner: pokedex
--

CREATE SEQUENCE public."Region_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Region_id_seq" OWNER TO pokedex;

--
-- Name: Region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokedex
--

ALTER SEQUENCE public."Region_id_seq" OWNED BY public."Region".id;


--
-- Name: _PokemonToPokemonAbility; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."_PokemonToPokemonAbility" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_PokemonToPokemonAbility" OWNER TO pokedex;

--
-- Name: _PokemonToPokemonType; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."_PokemonToPokemonType" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_PokemonToPokemonType" OWNER TO pokedex;

--
-- Name: _PokemonWeaknesses; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public."_PokemonWeaknesses" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_PokemonWeaknesses" OWNER TO pokedex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: pokedex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO pokedex;

--
-- Name: JapaneseMeta id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."JapaneseMeta" ALTER COLUMN id SET DEFAULT nextval('public."JapaneseMeta_id_seq"'::regclass);


--
-- Name: Pokemon id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."Pokemon" ALTER COLUMN id SET DEFAULT nextval('public."Pokemon_id_seq"'::regclass);


--
-- Name: PokemonAbility id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonAbility" ALTER COLUMN id SET DEFAULT nextval('public."PokemonAbility_id_seq"'::regclass);


--
-- Name: PokemonEvolution id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonEvolution" ALTER COLUMN id SET DEFAULT nextval('public."PokemonEvolution_id_seq"'::regclass);


--
-- Name: PokemonType id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonType" ALTER COLUMN id SET DEFAULT nextval('public."PokemonType_id_seq"'::regclass);


--
-- Name: PrimaryColor id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PrimaryColor" ALTER COLUMN id SET DEFAULT nextval('public."PrimaryColor_id_seq"'::regclass);


--
-- Name: Region id; Type: DEFAULT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."Region" ALTER COLUMN id SET DEFAULT nextval('public."Region_id_seq"'::regclass);


--
-- Data for Name: JapaneseMeta; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."JapaneseMeta" (id, kyodai_flg, image_s, sub_name, sub, type_2, image_m, no, type_1, takasa, zukan_no, name, omosa, "pokemonId") FROM stdin;
\.
COPY public."JapaneseMeta" (id, kyodai_flg, image_s, sub_name, sub, type_2, image_m, no, type_1, takasa, zukan_no, name, omosa, "pokemonId") FROM '$$PATH$$/3424.dat';

--
-- Data for Name: Pokemon; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."Pokemon" (id, "sourceId", name, slug, number, weight, height, hp, attack, defense, "spAttack", "spDefense", speed, image, "descriptionX", "descriptionY", "detailPageURL", "collectiblesSlug", "thumbnailAltText", "thumbnailImage", "subVariant", "createdAt", "updatedAt", "regionId") FROM stdin;
\.
COPY public."Pokemon" (id, "sourceId", name, slug, number, weight, height, hp, attack, defense, "spAttack", "spDefense", speed, image, "descriptionX", "descriptionY", "detailPageURL", "collectiblesSlug", "thumbnailAltText", "thumbnailImage", "subVariant", "createdAt", "updatedAt", "regionId") FROM '$$PATH$$/3415.dat';

--
-- Data for Name: PokemonAbility; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."PokemonAbility" (id, ability) FROM stdin;
\.
COPY public."PokemonAbility" (id, ability) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: PokemonEvolution; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."PokemonEvolution" (id, "order", "evolveFromId", "evolveToId") FROM stdin;
\.
COPY public."PokemonEvolution" (id, "order", "evolveFromId", "evolveToId") FROM '$$PATH$$/3430.dat';

--
-- Data for Name: PokemonType; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."PokemonType" (id, type) FROM stdin;
\.
COPY public."PokemonType" (id, type) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: PrimaryColor; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."PrimaryColor" (id, r, g, b, "pokemonId") FROM stdin;
\.
COPY public."PrimaryColor" (id, r, g, b, "pokemonId") FROM '$$PATH$$/3426.dat';

--
-- Data for Name: Region; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."Region" (id, "sourceId", name) FROM stdin;
\.
COPY public."Region" (id, "sourceId", name) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: _PokemonToPokemonAbility; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."_PokemonToPokemonAbility" ("A", "B") FROM stdin;
\.
COPY public."_PokemonToPokemonAbility" ("A", "B") FROM '$$PATH$$/3422.dat';

--
-- Data for Name: _PokemonToPokemonType; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."_PokemonToPokemonType" ("A", "B") FROM stdin;
\.
COPY public."_PokemonToPokemonType" ("A", "B") FROM '$$PATH$$/3420.dat';

--
-- Data for Name: _PokemonWeaknesses; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public."_PokemonWeaknesses" ("A", "B") FROM stdin;
\.
COPY public."_PokemonWeaknesses" ("A", "B") FROM '$$PATH$$/3421.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: pokedex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3413.dat';

--
-- Name: JapaneseMeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."JapaneseMeta_id_seq"', 1223, true);


--
-- Name: PokemonAbility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."PokemonAbility_id_seq"', 1850, true);


--
-- Name: PokemonEvolution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."PokemonEvolution_id_seq"', 9, true);


--
-- Name: PokemonType_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."PokemonType_id_seq"', 18, true);


--
-- Name: Pokemon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."Pokemon_id_seq"', 1234, true);


--
-- Name: PrimaryColor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."PrimaryColor_id_seq"', 1234, true);


--
-- Name: Region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokedex
--

SELECT pg_catalog.setval('public."Region_id_seq"', 9, true);


--
-- Name: JapaneseMeta JapaneseMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."JapaneseMeta"
    ADD CONSTRAINT "JapaneseMeta_pkey" PRIMARY KEY (id);


--
-- Name: PokemonAbility PokemonAbility_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonAbility"
    ADD CONSTRAINT "PokemonAbility_pkey" PRIMARY KEY (id);


--
-- Name: PokemonEvolution PokemonEvolution_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonEvolution"
    ADD CONSTRAINT "PokemonEvolution_pkey" PRIMARY KEY (id);


--
-- Name: PokemonType PokemonType_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonType"
    ADD CONSTRAINT "PokemonType_pkey" PRIMARY KEY (id);


--
-- Name: Pokemon Pokemon_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."Pokemon"
    ADD CONSTRAINT "Pokemon_pkey" PRIMARY KEY (id);


--
-- Name: PrimaryColor PrimaryColor_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PrimaryColor"
    ADD CONSTRAINT "PrimaryColor_pkey" PRIMARY KEY (id);


--
-- Name: Region Region_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."Region"
    ADD CONSTRAINT "Region_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: JapaneseMeta_pokemonId_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "JapaneseMeta_pokemonId_key" ON public."JapaneseMeta" USING btree ("pokemonId");


--
-- Name: PokemonAbility_ability_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "PokemonAbility_ability_key" ON public."PokemonAbility" USING btree (ability);


--
-- Name: PokemonType_type_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "PokemonType_type_key" ON public."PokemonType" USING btree (type);


--
-- Name: PrimaryColor_pokemonId_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "PrimaryColor_pokemonId_key" ON public."PrimaryColor" USING btree ("pokemonId");


--
-- Name: Region_name_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "Region_name_key" ON public."Region" USING btree (name);


--
-- Name: Region_sourceId_key; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "Region_sourceId_key" ON public."Region" USING btree ("sourceId");


--
-- Name: _PokemonToPokemonAbility_AB_unique; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "_PokemonToPokemonAbility_AB_unique" ON public."_PokemonToPokemonAbility" USING btree ("A", "B");


--
-- Name: _PokemonToPokemonAbility_B_index; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE INDEX "_PokemonToPokemonAbility_B_index" ON public."_PokemonToPokemonAbility" USING btree ("B");


--
-- Name: _PokemonToPokemonType_AB_unique; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "_PokemonToPokemonType_AB_unique" ON public."_PokemonToPokemonType" USING btree ("A", "B");


--
-- Name: _PokemonToPokemonType_B_index; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE INDEX "_PokemonToPokemonType_B_index" ON public."_PokemonToPokemonType" USING btree ("B");


--
-- Name: _PokemonWeaknesses_AB_unique; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE UNIQUE INDEX "_PokemonWeaknesses_AB_unique" ON public."_PokemonWeaknesses" USING btree ("A", "B");


--
-- Name: _PokemonWeaknesses_B_index; Type: INDEX; Schema: public; Owner: pokedex
--

CREATE INDEX "_PokemonWeaknesses_B_index" ON public."_PokemonWeaknesses" USING btree ("B");


--
-- Name: JapaneseMeta JapaneseMeta_pokemonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."JapaneseMeta"
    ADD CONSTRAINT "JapaneseMeta_pokemonId_fkey" FOREIGN KEY ("pokemonId") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PokemonEvolution PokemonEvolution_evolveFromId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonEvolution"
    ADD CONSTRAINT "PokemonEvolution_evolveFromId_fkey" FOREIGN KEY ("evolveFromId") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PokemonEvolution PokemonEvolution_evolveToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PokemonEvolution"
    ADD CONSTRAINT "PokemonEvolution_evolveToId_fkey" FOREIGN KEY ("evolveToId") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Pokemon Pokemon_regionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."Pokemon"
    ADD CONSTRAINT "Pokemon_regionId_fkey" FOREIGN KEY ("regionId") REFERENCES public."Region"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PrimaryColor PrimaryColor_pokemonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."PrimaryColor"
    ADD CONSTRAINT "PrimaryColor_pokemonId_fkey" FOREIGN KEY ("pokemonId") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _PokemonToPokemonAbility _PokemonToPokemonAbility_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonToPokemonAbility"
    ADD CONSTRAINT "_PokemonToPokemonAbility_A_fkey" FOREIGN KEY ("A") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PokemonToPokemonAbility _PokemonToPokemonAbility_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonToPokemonAbility"
    ADD CONSTRAINT "_PokemonToPokemonAbility_B_fkey" FOREIGN KEY ("B") REFERENCES public."PokemonAbility"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PokemonToPokemonType _PokemonToPokemonType_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonToPokemonType"
    ADD CONSTRAINT "_PokemonToPokemonType_A_fkey" FOREIGN KEY ("A") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PokemonToPokemonType _PokemonToPokemonType_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonToPokemonType"
    ADD CONSTRAINT "_PokemonToPokemonType_B_fkey" FOREIGN KEY ("B") REFERENCES public."PokemonType"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PokemonWeaknesses _PokemonWeaknesses_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonWeaknesses"
    ADD CONSTRAINT "_PokemonWeaknesses_A_fkey" FOREIGN KEY ("A") REFERENCES public."Pokemon"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PokemonWeaknesses _PokemonWeaknesses_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pokedex
--

ALTER TABLE ONLY public."_PokemonWeaknesses"
    ADD CONSTRAINT "_PokemonWeaknesses_B_fkey" FOREIGN KEY ("B") REFERENCES public."PokemonType"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pokedex
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

